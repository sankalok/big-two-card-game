import java.util.*;
import java.net.*;
import java.io.*;
import javax.swing.*;
/**
 * The BigTwoClient class implements the CardGame interface and NetworkGame interface. It
 * is used to model a Big Two card game that supports 4 players playing over the internet.
 * 
 * @author Sankalok Sen (UID: 3035667869)
 */
public class BigTwoClient implements CardGame, NetworkGame
{
	/**
	 * An integer specifying the number of players.
	 */
	private int numOfPlayers;
	/**
	 * A deck of cards.
	 */
	private Deck deck;
	/**
	 * A list of players.
	 */
	private ArrayList<CardGamePlayer> playerList;
	/**
	 * A list of hands played on the table.
	 */
	private ArrayList<Hand> handsOnTable;
	/**
	 * An integer specifying the playerID (i.e., index) of the local player.
	 */
	private int playerID;
	/**
	 * A string specifying the name of the local player.
	 */
	private String playerName;
	/**
	 * A string specifying the IP address of the game server.
	 */
	private String serverIP;
	/**
	 * An integer specifying the TCP port of the game server.
	 */
	private int serverPort;
	/**
	 * A socket connection to the game server.
	 */
	private Socket sock;
	/**
	 * An ObjectOutputStream for sending messages to the server.
	 */
	private ObjectOutputStream oos;
	/**
	 * An integer specifying the index of the player for the current turn.
	 */
	private int currentIdx;
	/**
	 * A Big Two table which builds the GUI for the game and handles all user actions.
	 */
	private BigTwoTable table;
	/**
	 * NEWLY ADDED INSTANCE VARIABLES.
	 */
	/**
	 * An ObjectInputStream for receiving messages from the server. (Deserializing the object).
	 */
	private ObjectInputStream ois;
	/**
	 * A public constructor for creating a Big Two client. It performs the following:
	 * (i) create 4 players and add them to the list of players;
	 * (ii) create a Big Two table which builds the GUI for the game and handles user actions;
	 * (iii) make a connection to the game server by calling the makeConnection() method from the 
	 * NetworkGame interface.
	 */
	public BigTwoClient()
	{
		/**
		 * Initializing the new playerList.
		 */
		playerList = new ArrayList<CardGamePlayer>();
		/**
		 * Integer to iterate through the ArrayList for adding 4 players.
		 */
		int i;
		/**
		 * Creating 4 players and adding them to the ArrayList.
		 */
		for(i = 0; i <= 3; i++)
		{
			/**
			 * Creating new player for each iteration and adding them to the playerList.
			 */
			CardGamePlayer newPlayer = new CardGamePlayer();
			playerList.add(newPlayer);
		}
		/**
		 * Initializing the current index holding the index of the current player to a default value.
		 */
		currentIdx = -999;
		/**
		 * Initializing the new handsOnTable.
		 */
		handsOnTable = new ArrayList<Hand>();
		/**
		 * Creating a Big Two table which builds the GUI for the game and handles user actions.
		 */
		table = new BigTwoTable(this);
		table.disable();
		/**
		 * Making a connection to the game server by calling the makeConnection() method from the 
		 * NetworkGame interface.
		 */
		makeConnection();
		table.repaint();
	}
	/**
	 * A method for getting the number of players.
	 * Getter Method.
	 * 
	 * @return NumOfPlayers
	 * 		Returns the number of players playing the BigTwo game.
	 */
	public int getNumOfPlayers()
	{
		return numOfPlayers;
	}
	/**
	 * A method for retrieving the deck of cards being used.
	 * Getter Method.
	 * 
	 * @return Deck
	 * 		Returns the Deck deck object.
	 */
	public Deck getDeck()
	{
		return this.deck;
	}
	/**
	 * A method for retrieving the list of players.
	 * Getter Method.
	 * 
	 * @return ArrayList<CardGamePlayer>
	 * 		Returns the list of players.
	 */
	public ArrayList<CardGamePlayer> getPlayerList()
	{
		return playerList;
	}
	/**
	 * A method for retrieving the list of hands played on the table.
	 * Getter Method.
	 * 
	 * @return ArrayList<Hand>
	 * 		Returns the list of hands played.
	 */
	public ArrayList<Hand> getHandsOnTable()
	{
		return handsOnTable;
	}
	/**
	 * A method for retrieving the index of the current player.
	 * Getter Method.
	 * 
	 * @return integer index currentIdx
	 * 		Returns index of the current player.
	 */
	public int getCurrentIdx()
	{
		return currentIdx;
	}
	/**
	 * A method for starting/restarting the game with a given shuffled deck of cards. We:
	 * (i) remove all the cards from the players as well as from the table;
	 * (ii) distribute the cards to the players;
	 * (iii) identify the player who holds the 3 of Diamonds;
	 * (iv) set the currentIdx of the BigTwoClient instance to the playerID (i.e., index) of the
	 * player who holds the 3 of Diamonds;
	 * (v) set the activePlayer of the BigTwoTable instance to the playerID (i.e., index) of the
	 * local player (i.e., only shows the cards of the local player and the local player can only
	 * select cards from his/her own hand).
	 * 
	 * * @param deck
	 * 		A shuffled deck of cards used as argument to start the game.
	 */
	public void start(Deck deck)
	{
		/**
		 * Iterators integers to help in running the loops.
		 */
		int i, j;
		currentIdx = -999;
		/**
		 * Removing all elements from the handsOnTable.
		 */
		handsOnTable.removeAll(handsOnTable);
		/**
		 * Removing all the cards from the players' hands.
		 */
		for(i = 0; i < playerList.size(); i++)
		{
			playerList.get(i).getCardsInHand().removeAllCards();
		}
		/**
		 * Distributing the deck between the four players.
		 */
		for(i = 0; i < 4; i++)
		{
			for(j = 0; j < 13; j++)
			{
				/**
				 * ith player gets 13 cards each.
				 */
				playerList.get(i).addCard(deck.getCard((13 * i) + j));
			}
		}
		/**		
		 * Sorts the cards for the four players as per the output requirements.
		 * Sorted from lowest rank to highest rank, and for same ranks, from lowest to highest suits.
		 */
		for(i = 0; i < 4; i++)
		{
			/**
			 * Cards get sorted following the BigTwo rule requirements.
			 */
			playerList.get(i).getCardsInHand().sort();
		}
		/**
		 * Identifying the player who holds the 3 of Diamonds.
		 */
		/**
		 * The 3 of Diamonds card, the player who has it starts the game.
		 */
		Card threeOfDiamonds = new Card(0, 2);
		/**
		 * Executing a for loop and finding the player who has 3 of Diamonds, who shall start the game.
		 */
		for(i = 0; i < 4; i++)
		{
			/**
			 * The player with the 3 of Diamonds starts the game, so stores the index of the
			 * starting player.
			 */
			if(playerList.get(i).getCardsInHand().contains(threeOfDiamonds))
			{
				currentIdx = i;
				break;
			}
		}
		/**
		 * Setting the activePlayer of the BigTwoTable instance to the playerID (i.e., index) of the local
		 * player.
		 */
		table.setActivePlayer(getPlayerID());
		table.repaint();
	}
	/**
	 * A method for making a move by a player with the specified playerID using the cards specified by
	 * the list of indices. This method should be called from the BigTwoTable when the local player
	 * presses either the �Play� or �Pass� button. You should create a CardGameMessage object of the
	 * type MOVE, with the playerID and data in this message being -1 and cardIdx, respectively, 
	 * and send it to the game server using the sendMessage() method from the NetworkGame 
	 * interface.
	 * 
	 * @param playerId
	 * 		Integer storing the ID of the players currently playing.
	 * @param cardIdx
	 * 		List of integers storing the indexes of the cards of the player currently playing.
	 */
	public void makeMove(int playerID, int[] cardIdx)
	{
		/**
		 * MOVE = 6 (from CardGameMessage.java)
		 * Creating a new CardGameMessage object of the type MOVE, with the playerID and data using the
		 * sendMessage() method.
		 */
		CardGameMessage cardGameMessage = new CardGameMessage(6, -1, cardIdx);
		this.sendMessage(cardGameMessage);
	}
	/**
	 * A method for checking a move made by a player. This method should be called from the
	 * parseMessage() method from the NetworkGame interface when a message of the type MOVE is
	 * received from the game server. The playerID and data in this message give the playerID of the
	 * player who makes the move and a reference to a regular array of integers specifying the
	 * indices of the selected cards, respectively. These are used as the arguments in calling the 
	 * checkMove() method.
	 * 
	 * @param playerID
	 * 		Integer storing the ID of the players currently playing.
	 * @param cardIdx
	 * 		List of integers storing the indexes of the cards of the player currently playing.
	 */
	public void checkMove(int playerID, int[] cardIdx)
	{
		/**
		 * The 3 of Diamonds card, the player who has it starts the game.
		 */
		Card threeOfDiamonds = new Card(0, 2);
		/**
		 * Boolean which remains true which a legal hand is placed else turns false once we find an
		 * illegal hand has been played.
		 */
		boolean legalHand = true;
		/**
		 * CardList created to store the list of cards of the current player playing his/her hand.
		 */
		CardList cardList = new CardList();
		/**
		 * Checks if legal playerID has been used and the cardIdx list is not empty
		 */
		if((playerID >= 0) && (playerID <= 3) && (cardIdx != null))
		{
			/**
			 * Returns the list of cards played by the player.
			 */
			cardList = playerList.get(playerID).play(cardIdx);
			/**
			 * Returns a valid hand from the specified cardlist, else returns a null value.
			 */
			Hand hand = composeHand(playerList.get(playerID), cardList);
			/**
			 * If the table is empty, that is, it is the start of the game.
			 */
			if(handsOnTable.isEmpty() == true)
			{
				/**
				 * Checks if Hand is containing three of diamonds
				 */
				if(((hand.contains(threeOfDiamonds)) == true) && (hand.isValid() == true))
				{
					legalHand = true;
				}
				else
				{
					legalHand = false;
				}
			}
			/**
			 * If the table is non empty.
			 */
			else if(handsOnTable.isEmpty() == false)
			{
				/**
				 * When the starting move has been already played so player index does not
				 * equal the index of the player who previously played.
				 */
				if(handsOnTable.get(handsOnTable.size() - 1).getPlayer() != playerList.get(playerID) && (hand.isEmpty() == false))
				{
					/**
					 * Checks if the hand played can beat the hand present on the table or not.
					 */
					legalHand = hand.beats(handsOnTable.get(handsOnTable.size() - 1));
				}
				else if(handsOnTable.get(handsOnTable.size() - 1).getPlayer() != playerList.get(playerID) && (hand.isEmpty() == true))
				{
					/**
					 * Cannot beat since Hand is empty.
					 */
					legalHand = false;
				}
				else if(handsOnTable.get(handsOnTable.size() - 1).getPlayer() == playerList.get(playerID) && (hand.isEmpty() == false))
				{
					/**
					 * LegalHand becomes true since here the player index == starting player index.
					 * So, one complete round of Passes have been played and the position is back to the player
					 * who played in the previous round before the round of Passes, and now that player
					 * can play any legal hand the player wants.
					 */
					legalHand = true;
				}
				else if(handsOnTable.get(handsOnTable.size() - 1).getPlayer() == playerList.get(playerID) && (hand.isEmpty() == true))
				{
					/**
					 * Cannot beat since Hand is empty.
					 */
					legalHand = false;
				}
			}
			/**
			 * If the legal hand is played and the hand is valid.
			 */
			if((legalHand == true) && (hand.isValid() == true))
			{
				/**
				 * Iterator for for loops.
				 */
				int i;
				/**
				 * Executing a for loop to remove the cards played.
				 */
				for(i = 0; i < cardList.size(); i++)
				{
					/**
					 * Removes the cards one by one after a legal hand has been played.
					 */
					playerList.get(playerID).getCardsInHand().removeCard(cardList.getCard(i));
				}
				/**
				 * We add the hand played to the hands on table.
				 */
				handsOnTable.add(hand);
				/**
				 * Printing the player, hand and type of hand played.
				 */
				table.printMsg(getPlayerList().get(currentIdx).getName() + "'s turn:");
				table.printMsg("{" + hand.getType() + "} " + hand);
				/**
				 * Changes the current player index so now the next player can play his/her move.
				 */
				currentIdx = (currentIdx + 1);
				if(currentIdx > 3)
				{
					currentIdx = currentIdx - 4;
				}
				/**
				 * Set the Active Player to the new Active Player.
				 */
				table.setActivePlayer(currentIdx);
			}
			else if((legalHand == false) || (hand.isValid() == false))
			{
				/**
				 * Print that the move played is not a legal move.
				 */
				table.printMsg(getPlayerList().get(currentIdx).getName() + "'s turn:");
				table.printMsg(cardList + " <== Not a legal move!!!");
			}
		}
		/**
		 * If the cardIdx is null.
		 */
		else if(cardIdx == null)
		{
			/**
			 * If the hands on table is not empty and starting player index not equals to player index,
			 * it means some moves of hands have already been played, and now a null hand has been played,
			 * signifying a Pass by the current player to shift play to the next player.
			 */
			if((handsOnTable.isEmpty() == false) && (handsOnTable.get(handsOnTable.size() - 1).getPlayer() != playerList.get(playerID)))
			{
				/**
				 * Pass played, shifting the move to the next player.
				 */
				table.printMsg(getPlayerList().get(currentIdx).getName() + "'s turn:");
				table.printMsg("{Pass}");
				/**
				 * Changes the current player index so now the next player can play his/her move.
				 */
				currentIdx = (currentIdx + 1);
				if(currentIdx > 3)
				{
					currentIdx = currentIdx - 4;
				}
				/**
				 * Set the Active Player to the new Active Player.
				 */
				table.setActivePlayer(currentIdx);
				/**
				 * The null hand is still legal as the game continues to next player as is and the current
				 * player has just passes his or her hand.
				 */
				legalHand = true;
			}
			else
			{
				/**
				 * Else, we find that an illegal move has been played.
				 */
				table.printMsg(getPlayerList().get(currentIdx).getName() + "'s turn:");
				table.printMsg("{Pass} <== Not a legal move!!!");
				legalHand = false;
			}
		}
		/**
		 * Repainting the table.
		 */
		table.repaint();
		/**
		 * Checking if game has ended
		 */
		if(endOfGame() == true)
		{
			/**
			 * End game message and printing the end of the game status.
			 */
			String endGameMsg = "Game ends.\n";
			/**
			 * The index of the active player has been set to less than 0 signifying the end of the game
			 * and repaints the table.
			 */
			table.setActivePlayer(-999);
			table.repaint();
			/**
			 * Iterator for for loop.
			 */
			int i;
			/**
			 * Executing the for loop to show the ending statistics and who won.
			 */
			for(i = 0; i <= 3; i++)
			{
				if(playerList.get(i).getCardsInHand().size() == 0)
				{
					/**
					 * Player who won.
					 */
					endGameMsg += (this.getPlayerList().get(i).getName() + " wins the game.\n");
				}
				else
				{
					/**
					 * How many cards each of the other 3 players still hold in their hands.
					 */
					endGameMsg += (this.getPlayerList().get(i).getName() + " has " + playerList.get(i).getCardsInHand().size() + " cards in hand.\n");
				}
			}
			/**
			 * Disables the table.
			 */
			table.disable();
			for (i = 0; i <= 3; i++)
	        {
				/**
				 * Removes all cards.
				 */
				getPlayerList().get(i).removeAllCards();
	        }
			/**
			 * Showing the end game Msg diaglog.
			 */
			JOptionPane.showMessageDialog(null, endGameMsg);
			/**
			 * READY = 4
			 */
			CardGameMessage ready = new CardGameMessage(4, -1, null);
			sendMessage(ready);
		}
	}
	/**
	 * A method for checking if the game ends.
	 * 
	 * @param boolean endOfGame
	 * 		Returns true if the game has ended, and false otherwise.
	 */
	public boolean endOfGame()
	{
		/**
		 * Iterator integer to help in running the loops.
		 */
		int i;
		/**
		 * Returns true if games has ended and false otherwise.
		 */
		for(i = 0; i < playerList.size(); i++)
		{
			if(playerList.get(i).getCardsInHand().isEmpty() == true)
			{
				return true;
			}
		}
		return false;
	}
	/**
	 * A method for getting the playerID (i.e., index) of the local player.
	 * Getter Method.
	 *  
	 * @return int playerID
	 * 		Returns the playerID of the local player.
	 */
	public int getPlayerID()
	{
		return playerID;
	}
	/**
	 * A method for setting the playerID (i.e., index) of the local player. This method should be called
	 * from the parseMessage() method when a message of the type PLAYER_LIST is received from the
	 * game server.
	 * Setter Method.
	 * 
	 * @param int playerID
	 * 		Sets the playerID of the local player.
	 */
	public void setPlayerID(int playerID)
	{
		this.playerID = playerID;
	}
	/**
	 * A method for getting the name of the local player.
	 * Getter Method.
	 * 
	 * @return String playerName
	 * 		Returns the playerName of the local player.
	 */
	public String getPlayerName()
	{
		return playerName;
	}
	/**
	 * A method for setting the name of the local player. 
	 * Setter Method.
	 * 
	 * @param String playerName
	 * 		Sets the playerName of the local player.
	 */
	public void setPlayerName(String playerName)
	{
		playerList.get(playerID).setName(playerName);
	}
	/**
	 * A method for getting the IP address of the game server.
	 * Getter Method.
	 * 
	 * @return String serverIP
	 * 		Returns the serverIP of the game server.
	 */
	public String getServerIP()
	{
		return serverIP;
	}
	/**
	 * A method for setting the IP address of the game server.
	 * Setter Method.
	 * 
	 * @param String serverIP
	 * 		Sets the serverIP of the game server.
	 */
	public void setServerIP(String serverIP)
	{
		this.serverIP = serverIP;
	}
	/**
	 * A method for getting the TCP port of the game server.
	 * Getter Method.
	 * 
	 * @return int serverPort
	 * 		Returns the TCP serverPort of the game server.
	 */
	public int getServerPort()
	{
		return serverPort;
	}
	/**
	 * A method for setting the TCP port of the game server.
	 * Setter Method.
	 * 
	 * @param int serverPort
	 * 		Sets the TCP serverPort of the game server.
	 */
	public void setServerPort(int serverPort)
	{
		this.serverPort = serverPort;
	}
	/**
	 * A method for making a socket connection with the game server. Upon successful connection, we:
	 * (i) create an ObjectOutputStream for sending messages to the game server;
	 * (ii) create a thread for receiving messages from the game server.
	 */
	public void makeConnection()
	{
		/**
		 * We create a random array and select a random position so as to store the name of the player
		 * as such if they input an invalid type name.
		 */
		String[] randomNames = {"Random Ant", "Random Balloon", "Random Cat", "Random Dog"};
		int randomPos = (int)((Math.random() * (randomNames.length - 1 - 0)) + 0);
		/**
		 * Stores the player name.
		 */
		playerName = JOptionPane.showInputDialog("Enter your Name (we generate a random name otherwise): ", "Random Elephant");
		/**
		 * Stores the player name.
		 */
		if(playerName.equals(null) || playerName.equals(""))
		{
			playerName = (randomNames[randomPos]);
		}
		/**
		 * Hardcoding the IP address for the server.
		 */
		setServerIP("127.0.0.1");
		/**
		 * Hardcoding the TCP port for the server.
		 */
		setServerPort(2396);
		/**
		 * A try-catch scenario to handle exceptions that may arise.
		 */
		try
		{
			/**
			 * Creating the socket connection.
			 */
			sock = new Socket(getServerIP(), getServerPort());
			/**
			 * Creating the object output stream.
			 */
			oos = new ObjectOutputStream(sock.getOutputStream());
			/**
			 * Create a thread for receiving messages from the game server, and starting the thread.
			 */
			Thread thread = new Thread(new ServerHandler());
			thread.start();
			/**
			 * Sent by a client to the server when a connection is established. In this
			 * message, playerID specifies the playerID of the player, and data is
			 * simply null (not being used).
			 * 
			 * JOIN = 1
			 */
			CardGameMessage join = new CardGameMessage(1, -1, this.getPlayerName());
			sendMessage(join);
			/**
			 * Sent by a client to the server to indicate it is ready for a new game. The server will also
			 * broadcast this message upon receiving it. In this message, playerID specifies the player who
			 * becomes ready for a new game (for the message broadcast by the server) or -1 (for the message
			 * sent by a client), and data is simply null (not being used).
			 * 
			 * READY = 4
			 */
			CardGameMessage ready = new CardGameMessage(4, -1, null);
			sendMessage(ready);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/**
	 * A method for parsing the messages received from the game server. This method should be called from
	 * the thread responsible for receiving messages from the game server. Based on the message type,
	 * different actions will be carried out (please refer to the general behavior of the client 
	 * described in the previous section).
	 * 
	 * @param GameMessage message
	 * 		Parses the messages received from the game server.
	 */
	public synchronized void parseMessage(GameMessage message)
	{
		/**
		 * Stores the type of the message.
		 */
		int messageType = message.getType();
		/**
		 * FULL= 0
		 */
		if(messageType == 0)
		{
			/**
			 * Setting active playerID
			 */
			playerID = message.getPlayerID();
			table.setActivePlayer(playerID);
			/**
			 * Setting the playerID.
			 */
			setPlayerID(message.getPlayerID());
			/**
			 * if the data received is not null.
			 */
			if((message.getData().equals(null)) == false)
			{
				/**
				 * Iterator helping in executing the loop.
				 */
				int i = 0;
				for(i = 0; i <= 3; i++)
				{
					/**
					 * Gets the data and sets the player name.
					 */
					this.getPlayerList().get(i).setName(((String[])message.getData())[i]);
				}
			}
		}
		else if(messageType == 1)
		{
			/**
			 * A new player joins the game.
			 */
			if((message.getData().equals(null)) == false)
			{
				this.getPlayerList().get(message.getPlayerID()).setName((String)message.getData());
				table.repaint();
				table.printMsg(playerList.get(message.getPlayerID()).getName() + " has joined the game.");
			}
		}
		else if(messageType == 2)
		{
			/**
			 * The game is full.
			 */
			table.printMsg("The game is full.");
			table.repaint();
		}
		else if(messageType == 3)
		{
			/**
			 * A player quits the game.
			 */
			if((this.endOfGame()) == false)
			{
				table.printMsg(playerList.get(message.getPlayerID()).getName() + " has quit the game.");
				this.getPlayerList().get(message.getPlayerID()).setName("");
				/**
				 * Send a ready message to restart.
				 */
				CardGameMessage readyMsg = new CardGameMessage(4, -1, null);
				this.sendMessage(readyMsg);
				table.disable();
				table.repaint();
			}
		}
		else if(messageType == 4)
		{
			/**
			 * When the player is ready.
			 */
			table.printMsg(this.getPlayerList().get(message.getPlayerID()).getName() + " is ready.");
			table.repaint();
		}
		else if(messageType == 5)
		{
			/**
			 * Broadcast from server that all players are ready to join.
			 */
			this.start(((BigTwoDeck)message.getData()));
			table.enable();
			table.repaint();
		}
		else if(messageType == 6)
		{
			/**
			 * When a local player makes a move.
			 */
			this.checkMove(message.getPlayerID(), (int[])message.getData());
			/**
			 * Printing whether it's the local player's turn or someone else.
			 */
			if(this.getPlayerID() != this.currentIdx)
			{
				table.printMsg(this.getPlayerList().get(message.getPlayerID()).getName() + "'s turn.");
			}
			else
			{
				table.printMsg("Your turn.");
			}
			table.repaint();
		}
		else if(messageType == 7)
		{
			/**
			 * Sent by a client to the server when the local player press [ENTER] in the chat input field.
			 */
			table.printChatMsg((String)message.getData());
		}
	}
	/**
	 * A method for sending the specified message to the game server. This method should be called whenever
	 * the client wants to communicate with the game server or other clients.
	 * 
	 * @param GameMessage message
	 * 		Sends the messages received from the game server.
	 */
	public void sendMessage(GameMessage message)
	{
		try
		{
			oos.writeObject(message);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/**
	 * An inner class that implements the Runnable interface. We implement the run() method from the 
	 * Runnable interface and create a thread with an instance of this class as its job in the
	 * makeConnection() method from the NetworkGame interface for receiving messages from the game
	 * server. Upon receiving a message, the parseMessage() method from the NetworkGame interface
	 * should be called to parse the messages accordingly.
	 * 
	 * @author Sankalok Sen (UID: 3035667869)
	 */
	class ServerHandler implements Runnable
	{
		/**
		 * Implementing the run() method from the Runnable interface 
		 */
		public void run()
		{
			try
			{
				ois = new ObjectInputStream(sock.getInputStream());
				while(((CardGameMessage)ois.readObject()).equals(null) == false)
				{
					parseMessage((CardGameMessage)ois.readObject());
				}				
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			table.repaint();
		}
	}
	/**
	 * A method for returning a valid hand from the specified list of cards of the player. 
	 * Returns "null" if no valid hand can be composed from the specified list of cards.
	 * 
	 * @return Hand
	 * 		Returns the hand if its a valid hand and null otherwise. 
	 * @param CardGamePlayer player
	 * 		Object which consists of a list of the players in the game.
	 * @param CardList cards
	 * 		Object which consists of the list of the cards being played by the current active player.
	 */
	public static Hand composeHand(CardGamePlayer player, CardList cards)
	{
		/**
		 * Creating a Single object.
		 */
		Single single = new Single(player, cards);
		/**
		 * Creating a Pair object.
		 */
		Pair pair = new Pair(player, cards);
		/**
		 * Creating a Triple object.
		 */
		Triple triple = new Triple(player, cards);
		/**
		 * Creating a Straight object.
		 */
		Straight straight = new Straight(player, cards);
		/**
		 * Creating a Flush object.
		 */
		Flush flush = new Flush(player, cards);
		/**
		 * Creating a FullHouse object.
		 */
		FullHouse fullhouse = new FullHouse(player, cards);
		/**
		 * Creating a Quad object.
		 */
		Quad quad = new Quad(player, cards);
		/**
		 * Creating a StraightFlush object.
		 */
		StraightFlush straightflush = new StraightFlush(player, cards);
		/**
		 * If straightflush is valid, returns straightflush.
		 */
		if(straightflush.isValid())
		{
			return straightflush;
		}
		/**
		 * If quad is valid, returns quad.
		 */
		else if(quad.isValid())
		{
			return quad;
		}
		/**
		 * If fullhouse is valid, returns fullhouse.
		 */
		else if(fullhouse.isValid())
		{
			return fullhouse;
		}
		/**
		 * If flush is valid, returns flush.
		 */
		else if(flush.isValid())
		{
			return flush;
		}
		/**
		 * If straight is valid, returns straight.
		 */
		else if(straight.isValid())
		{
			return straight;
		}
		/**
		 * If triple is valid, returns triple.
		 */
		else if(triple.isValid())
		{
			return triple;
		}
		/**
		 * If pair is valid, returns pair.
		 */
		else if(pair.isValid())
		{
			return pair;
		}
		/**
		 * If single is valid, returns pair.
		 */
		else if(single.isValid())
		{
			return single;
		}
		/**
		 * Returns a null hand when no valid hand can be made from the specified list of cards.
		 */
		return null;
	}
	/**
	 * A method for creating an instance of BigTwoClient.
	 * 
	 * @param args
	 * 		Not used in this BigTwo class.
	 */
	public static void main(String[] args)
	{
		BigTwoClient bigTwoClient = new BigTwoClient();
	}
}